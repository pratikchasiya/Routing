import React, { Fragment } from 'react'
import Header from './Header'

const About = () => {
  return (
   <Fragment>
     <div className='text-center'>About</div>
   </Fragment>
  )
}

export default Header(About)