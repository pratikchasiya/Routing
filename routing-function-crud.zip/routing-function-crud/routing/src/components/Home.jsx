import React, { Fragment } from 'react'
import Header from './Header'

const Home = () => {
  return (
  <Fragment>
      <div className='text-center'>Home</div>
  </Fragment>
  )
}

export default Header(Home)