import React, { Fragment } from 'react'
import Header from './Header'

const Contact = () => {
  return (
 <Fragment>
       <div className='text-center'>Contact</div>
 </Fragment>
  )
}

export default Header( Contact)